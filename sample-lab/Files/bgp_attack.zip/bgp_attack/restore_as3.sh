#!/bin/bash 


name="as3r-r103"
postfix="original"

source ./upload.sh
