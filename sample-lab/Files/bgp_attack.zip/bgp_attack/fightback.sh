#!/bin/bash 


name="as154r"
postfix="fightback"

source ./upload.sh
