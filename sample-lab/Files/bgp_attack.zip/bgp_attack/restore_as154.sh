#!/bin/bash 


name="as154r"
postfix="original"

source ./upload.sh
