#!/bin/bash 


name="as3r-r103"
postfix="fixproblem"

source ./upload.sh
