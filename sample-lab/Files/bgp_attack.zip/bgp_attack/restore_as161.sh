#!/bin/bash 


name="as161r"
postfix="original"

source ./upload.sh
