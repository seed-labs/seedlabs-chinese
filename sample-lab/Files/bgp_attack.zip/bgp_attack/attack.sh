#!/bin/bash 


name="as161r"
postfix="malicious"

source ./upload.sh
